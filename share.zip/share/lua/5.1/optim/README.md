<a name='optim.dok'></a>
# Optimization package

This package contains several optimization routines and a logger for [Torch](https://github.com/torch/torch7/blob/master/README.md):

 * [Overview](doc/intro.md);
 * [Optimization algorithms](doc/algos.md);
 * [Logger](doc/logger.md).

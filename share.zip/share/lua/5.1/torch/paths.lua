local paths = {}

paths.install_prefix = [[/home/hanjy/torch/install]]
paths.install_bin = [[/home/hanjy/torch/install/bin]]
paths.install_man = [[/home/hanjy/torch/install/share/man]]
paths.install_lib = [[/home/hanjy/torch/install/lib]]
paths.install_share = [[/home/hanjy/torch/install/share]]
paths.install_include = [[/home/hanjy/torch/install/include]]
paths.install_cmake = [[/home/hanjy/torch/install/share/cmake/torch]]

return paths
